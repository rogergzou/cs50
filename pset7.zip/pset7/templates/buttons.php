<p><a href="index.php">home</a>
<a href="buy.php">buy</a>
<a href="sell.php">sell</a>
<a href="history.php">history</a>
<a href="cash.php">add $5k cash</a>
<a href="register.php">register</a>
<a href="logout.php">logout</a>

</p>
