<p>

<?= print("Stock: " . $stock["name"]) ?>
<br/>
<?= print("Price: " . $stock["price"]) ?>
<br/>
<?
/* <?= htmlspecialchars($symbol) ?> 
 <?= htmlspecialchars($name) ?> 
<br/>
<?= htmlspecialchars($price) ?> */
?>

</p>
